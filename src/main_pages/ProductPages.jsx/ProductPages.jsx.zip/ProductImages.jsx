"use client";
import React, { useState, useRef, useEffect } from "react";
import { FaHeart } from "react-icons/fa";
import { FiZoomIn } from "react-icons/fi";
import { useSelector, useDispatch } from "react-redux";
import Image from "next/image";
import { addToCart, decrementCart } from "@/redux/cart/CartSlice";
import {
  addToWishlistLocal,
  addToWishlistServer,
  fetchUserWishlist,
  removeFromWishlistLocal,
  removeFromWishlistServer,
} from "@/redux/wishlist/wishlistSlice";
import { useRouter } from "next/navigation";
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from "swiper/modules";
import { motion } from "framer-motion";
import "swiper/css";
import "swiper/css/pagination";
import { GoPlus } from "react-icons/go";
import { HiMinus } from "react-icons/hi";

const ProductImagesSkeleton = () => {
  return (
    <div className="w-full animate-pulse">
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="flex flex-col lg:flex-row gap-4 relative p-4">
          <div className="hidden lg:flex flex-col gap-3 w-24">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="w-full h-20 rounded-xl bg-gray-300"></div>
            ))}
          </div>
          <div className="flex-1 rounded-2xl bg-gray-200 aspect-square"></div>
        </div>
        <div className="flex gap-3 p-4">
          <div className="flex-1 h-12 rounded-xl bg-gray-300"></div>
          <div className="flex-1 h-12 rounded-xl bg-gray-300"></div>
        </div>
      </div>
    </div>
  );
};

const ProductImages = ({
  product,
  setselectedImage,
  setMobileImageHigh,
  setShowMagnifier,
  showMagnifier,
  imageRef,
  setCursorPosition,
  setMagnifierPosition,
  cursorPosition,
}) => {
  const dispatch = useDispatch();
  const { loginData, isAuth } = useSelector((store) => store.Athentication);
  const { selectedVariant, status } = useSelector((state) => state.info);
  const { CartItems } = useSelector((state) => state.cart);
  const { items: wishlistItems } = useSelector((state) => state.wishlist);

  const [isMobile, setIsMobile] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const thumbnailContainerRef = useRef(null);
  const swiperRef = useRef(null);
  const router = useRouter();

  useEffect(() => {
    const checkIfMobile = () => setIsMobile(window.innerWidth <= 768);
    checkIfMobile();
    window.addEventListener("resize", checkIfMobile);
    return () => window.removeEventListener("resize", checkIfMobile);
  }, []);

  const getValidImageSrc = (src) =>
    src && src.trim() !== "" ? src : "https://via.placeholder.com/300";

  const productData = product?.[0] || {};
  const variants = productData?.simpleAttributes || [];
  const currentVariant = variants[selectedVariant] || {};
  const selectedVariantImages = currentVariant?.slider || [];
  const mainImage =
    selectedVariantImages[selectedImageIndex] ||
    currentVariant?.thumbnail ||
    productData?.thumbnail?.[0];

  useEffect(() => {
    if (mainImage) return setselectedImage(mainImage);
  }, [mainImage, setselectedImage]);

  const [isWishlisted, setIsWishlisted] = useState(false);
  useEffect(() => {
    if (currentVariant?._id && productData?._id) {
      const isInWishlist = wishlistItems.some(
        (item) =>
          item.ProductId === productData._id &&
          item.AttributeId === currentVariant._id
      );
      setIsWishlisted(isInWishlist);
    }
  }, [wishlistItems, currentVariant, productData]);

  const handleWishlistToggle = async () => {
    if (!loginData?._id) return router.push("/login");
    if (!productData || !currentVariant || !loginData?._id) return;

    const wishlistItem = {
      userId: loginData._id,
      UserName: loginData.Name,
      UserEmail: loginData.Email,
      UserMobile: loginData.Mobile,
      ProductId: productData._id,
      ProductName: productData.name,
      AttributeId: currentVariant._id,
      Mrp: currentVariant.mrp,
      Price: currentVariant.price,
      thumbnail: currentVariant.thumbnail || productData.thumbnail?.[0],
      shopId: productData.shopId || "4567898765456789",
      shopName: productData.shopName || "demooo",
      productSlug: productData.slugUrl,
    };

    try {
      if (isWishlisted) {
        await dispatch(
          removeFromWishlistServer({
            userId: loginData._id,
            ProductId: productData._id,
            AttributeId: currentVariant._id,
          })
        ).unwrap();
        dispatch(removeFromWishlistLocal(wishlistItem));
      } else {
        await dispatch(addToWishlistServer(wishlistItem)).unwrap();
        dispatch(addToWishlistLocal(wishlistItem));
      }
    } catch (error) {
      console.error("Wishlist operation failed:", error);
    }
  };

  useEffect(() => {
    if (isAuth && loginData?._id) dispatch(fetchUserWishlist(loginData._id));
  }, [isAuth, loginData?._id, dispatch]);

  const handleAddToCart = () => {
    if (!productData || !currentVariant) return;
    dispatch(
      addToCart({
        AttributeId: currentVariant._id,
        Mrp: currentVariant.mrp,
        Price: currentVariant.price,
        name: productData.name,
        thumbnail: currentVariant.thumbnail,
        shopId: productData.shopId,
        shopName: productData.shopName,
        slugurl: productData.slugUrl,
      })
    );
  };

  const buyNow = () => {
    if (!productData || !currentVariant) return;

    const cartItem = CartItems.find(
      (item) => item.AttributeId === currentVariant._id
    );

    if (!cartItem) {
      handleAddToCart();
    }

    router.push("/cart");
  };

  const handleDecrementToCart = () => {
    if (!productData || !currentVariant) return;
    dispatch(
      decrementCart({
        AttributeId: currentVariant._id,
        Mrp: currentVariant.mrp,
        Price: currentVariant.price,
        name: productData.name,
        thumbnail: currentVariant.thumbnail,
        shopId: productData.shopId,
        shopName: productData.shopName,
        slugurl: productData.slugUrl,
      })
    );
  };

  const handleSlideChange = (swiper) => {
    setSelectedImageIndex(swiper.activeIndex);
    const newImage =
      selectedVariantImages[swiper.activeIndex] ||
      currentVariant?.thumbnail ||
      productData?.thumbnail?.[0];
    setselectedImage(newImage);
  };

  const handleMouseMove = (e) => {
    if (!imageRef.current) return;
    const rect = imageRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setCursorPosition({ x, y });
    setMagnifierPosition({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100,
    });
  };

  if (
    status === "loading" ||
    !currentVariant ||
    !productData ||
    !product?.length
  ) {
    return <ProductImagesSkeleton />;
  }

  return (
    <div className="w-full">
      <div className="bg-white sm:rounded-2xl shadow-lg overflow-hidden">
        <div className="flex flex-col lg:flex-row gap-4 relative sm:px-4 sm:py-2">
          {/* Thumbnail Sidebar */}
          {!isMobile && (
            <motion.div
              className="hidden lg:flex flex-col gap-3 w-18"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              {selectedVariantImages.map((src, idx) => (
                <motion.button
                  key={idx}
                  onClick={() => setSelectedImageIndex(idx)}
                  className={`w-full h-[80px] rounded-xl overflow-hidden border-2 transition-all duration-300 ${
                    selectedImageIndex === idx
                      ? "border-rose-500 shadow-md"
                      : "border-gray-200 hover:border-gray-400"
                  }`}
                  whileHover={{ scale: 1.05 }}
                >
                  <Image
                    src={getValidImageSrc(src || productData?.thumbnail?.[0])}
                    alt={`Thumbnail ${idx + 1}`}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </motion.button>
              ))}
            </motion.div>
          )}

          {/* Main Image */}
          <motion.div
            className="relative flex-1 group rounded-sm overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            {isMobile ? (
              <div
                className="relative h-[100vh] w-full"
                onClick={() => setMobileImageHigh(true)}
              >
                <Swiper
                  ref={swiperRef}
                  initialSlide={selectedImageIndex}
                  onSlideChange={handleSlideChange}
                  pagination={{ dynamicBullets: true }}
                  modules={[Pagination]}
                  className="h-full w-full"
                >
                  {selectedVariantImages.map((src, idx) => (
                    <SwiperSlide key={idx}>
                      <Image
                        src={getValidImageSrc(
                          src || productData?.thumbnail?.[0]
                        )}
                        alt={`Product image ${idx + 1}`}
                        fill
                        className="object-cover "
                        priority={idx === 0}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              </div>
            ) : (
              <div
                className="relative h-140 w-full"
                onMouseEnter={() => setShowMagnifier(true)}
                onMouseLeave={() => setShowMagnifier(false)}
                onMouseMove={handleMouseMove}
              >
                <Image
                  src={getValidImageSrc(
                    mainImage || productData?.thumbnail?.[0]
                  )}
                  alt="Main product"
                  fill
                  className="object-contain transition-all duration-500"
                  priority
                />
                {showMagnifier && (
                  <div
                    className="absolute bg-white/40 pointer-events-none rounded-lg z-20"
                    style={{
                      width: "150px",
                      height: "100px",
                      left: `${cursorPosition.x - 75}px`,
                      top: `${cursorPosition.y - 75}px`,
                      display:
                        cursorPosition.x === 0 && cursorPosition.y === 0
                          ? "none"
                          : "block",
                    }}
                  />
                )}
                <motion.button
                  onClick={handleWishlistToggle}
                  className={`absolute top-4 right-4 p-3 rounded-full shadow-md transition-all ${
                    isWishlisted
                      ? "bg-rose-500 text-white"
                      : "bg-white/90 hover:bg-white text-gray-700"
                  }`}
                  whileHover={{ scale: 1.1 }}
                >
                  <FaHeart />
                </motion.button>
                <div className="absolute top-4 left-4 flex gap-2">
                  <motion.span
                    className="bg-cyan-500 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md animate-pulse"
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    transition={{ repeat: Infinity, duration: 0.8 }}
                  >
                    New
                  </motion.span>
                  <motion.span
                    className="bg-rose-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md"
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    transition={{ repeat: Infinity, duration: 0.8, delay: 0.2 }}
                  >
                    {Math.round(
                      (1 - currentVariant.price / currentVariant.mrp) * 100
                    )}
                    % OFF
                  </motion.span>
                </div>
              </div>
            )}
          </motion.div>
        </div>

        {/* Action Buttons */}
        <div
          className={`sm:p-3 bg-gray-50 border border-gray-200 w-full flex flex-col ${
            isMobile
              ? "fixed bottom-0 left-0 right-0 z-[100] px-10"
              : "sticky bottom-0"
          }`}
        >
          <div className="flex flex-row gap-3 sm:px-10 sm:my-0 my-2">
            {(() => {
              const cartItem = CartItems.find(
                (item) => item.AttributeId === currentVariant._id
              );
              const quantity = cartItem?.cart_Quentity || 0;
              if (quantity === 0) {
                return (
                  <motion.button
                    className="flex-1 bg-rose-500 hover:bg-rose-600 text-white font-medium py-3 rounded-sm shadow-md transition-all duration-300"
                    onClick={handleAddToCart}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    ADD TO CART
                  </motion.button>
                );
              } else {
                return (
                  <motion.div
                    className="flex-1 bg-rose-500 text-white font-medium py-2 shadow-md flex items-center justify-between px-3 rounded-sm "
                    whileHover={{ scale: 1.02 }}
                  >
                    <button
                      onClick={handleDecrementToCart}
                      className=" px-3 text-2xl cursor-pointer"
                    >
                      <HiMinus />
                    </button>
                    <span className="text-lg">{quantity}</span>
                    <button
                      onClick={handleAddToCart}
                      className=" px-3 text-2xl cursor-pointer"
                    >
                      <GoPlus />
                    </button>
                  </motion.div>
                );
              }
            })()}

            <motion.button
              className="flex-1 bg-[#2f415d] text-white font-medium py-3 shadow-md transition-all duration-300 rounded-sm"
              onClick={buyNow}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              BUY NOW
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductImages;
