"use client";
import React, { useState, useEffect } from "react";
import { RiCoupon2Fill } from "react-icons/ri";
import { IoStar, IoStarHalf, IoStarOutline } from "react-icons/io5";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedVariant } from "@/redux/product/productSlice";
import { useRouter } from "next/navigation";

const ProductDetails = () => {
  const {
    rating,
    totalRatings,
    ratingBreakdown,
    customerReviews,
    status,
    error,
  } = useSelector((state) => state.reviews);
  const dispatch = useDispatch();
  const { product, selectedVariant } = useSelector((state) => state.info);
  const [showVariantModal, setShowVariantModal] = useState(false);
  const [tempSelection, setTempSelection] = useState({
    field1: "",
    field2: "",
    field3: "",
  });

  const productData = product?.[0] || {};
  const variants = productData?.simpleAttributes || [];
  const currentVariant = variants[selectedVariant] || {};

  const router = useRouter();
  // Helper function to ensure valid image src
  const getValidImageSrc = (src) => {
    return src && src.trim() !== "" ? src : "https://via.placeholder.com/64";
  };

  // Get available variant fields
  const variantFields = [
    productData.fieldname1,
    productData.fieldname2,
    productData.fieldname3,
  ].filter(Boolean);

  // State for selected values
  const [selectedValues, setSelectedValues] = useState({
    field1: "",
    field2: "",
    field3: "",
  });

  // Initialize selected values
  useEffect(() => {
    if (variants.length > 0) {
      const variant = variants[selectedVariant] || variants[0];
      setSelectedValues({
        field1: variant.fieldValue1 || "",
        field2: variant.fieldValue2 || "",
        field3: variant.fieldValue3 || "",
      });
      setTempSelection({
        field1: variant.fieldValue1 || "",
        field2: variant.fieldValue2 || "",
        field3: variant.fieldValue3 || "",
      });
    }
  }, [variants, selectedVariant]);

  // Update variant when selections change
  useEffect(() => {
    const matchingVariant = variants.findIndex(
      (v) =>
        v.fieldValue1 === selectedValues.field1 &&
        v.fieldValue2 === selectedValues.field2 &&
        v.fieldValue3 === selectedValues.field3
    );

    if (matchingVariant !== -1 && matchingVariant !== selectedVariant) {
      dispatch(setSelectedVariant(matchingVariant));
    }
  }, [selectedValues, variants, dispatch, selectedVariant]);

  // Handle variant selection in modal
  const handleApply = () => {
    setSelectedValues(tempSelection);
    setShowVariantModal(false);
  };

  const handleCancel = () => {
    setTempSelection(selectedValues);
    setShowVariantModal(false);
  };

  // Calculate discount percentage
  const discountPercentage =
    currentVariant.price && currentVariant.mrp
      ? Math.round((1 - currentVariant.price / currentVariant.mrp) * 100)
      : 0;

  // Render star ratings
  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <IoStar key={i} className="text-yellow-500 text-sm md:text-base" />
        );
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <IoStarHalf
            key={i}
            className="text-yellow-500 text-sm md:text-base"
          />
        );
      } else {
        stars.push(
          <IoStarOutline
            key={i}
            className="text-yellow-500 text-sm md:text-base"
          />
        );
      }
    }

    return stars;
  };

  // Get unique values for a specific field
  const getUniqueValues = (fieldIndex, filterValues = {}) => {
    const filtered = variants.filter((variant) => {
      return Object.keys(filterValues).every((key) => {
        if (!filterValues[key]) return true;
        return variant[key] === filterValues[key];
      });
    });

    return [
      ...new Set(
        filtered.map((v) => {
          if (fieldIndex === 0) return v.fieldValue1;
          if (fieldIndex === 1) return v.fieldValue2;
          if (fieldIndex === 2) return v.fieldValue3;
          return "";
        })
      ),
    ].filter(Boolean);
  };

  // Render variant selector for a field - for desktop
  const renderVariantSelector = (fieldIndex) => {
    const fieldName = variantFields[fieldIndex];
    if (!fieldName) return null;

    const filterValues = {};
    if (fieldIndex > 0) filterValues.fieldValue1 = selectedValues.field1;
    if (fieldIndex > 1) filterValues.fieldValue2 = selectedValues.field2;

    const options = getUniqueValues(fieldIndex, filterValues);
    const currentValue = selectedValues[`field${fieldIndex + 1}`];

    const isColorField = fieldName.toLowerCase().includes("color");

    return (
      <div className="mb-6 hidden md:block" key={fieldIndex}>
        <h3 className="text-sm font-semibold mb-3 uppercase tracking-wider text-gray-600">
          {fieldName}
        </h3>
        <div className="flex flex-wrap gap-3">
          {options.map((option, index) => (
            <button
              key={index}
              onClick={() =>
                setSelectedValues((prev) => ({
                  ...prev,
                  [`field${fieldIndex + 1}`]: option,
                }))
              }
              className={`
                ${isColorField ? "w-16 h-16" : "px-4 py-2 min-w-[60px]"}
                border-2 rounded-md transition-all flex items-center justify-center
                ${
                  currentValue === option
                    ? isColorField
                      ? "border-rose-500 shadow-md"
                      : "border-black bg-black text-white"
                    : "border-gray-200 hover:border-gray-400"
                }
              `}
              aria-label={`Select ${option}`}
            >
              {isColorField ? (
                <img
                  src={getValidImageSrc(
                    variants.find((v) =>
                      fieldIndex === 0
                        ? v.fieldValue1 === option
                        : fieldIndex === 1
                        ? v.fieldValue2 === option
                        : v.fieldValue3 === option
                    )?.thumbnail
                  )}
                  alt={option}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              ) : (
                <span className="text-center">{option}</span>
              )}
            </button>
          ))}
        </div>
      </div>
    );
  };

  // Render selected variant summary - for mobile
  const renderVariantSummary = () => {
    return (
      <div className="mb-6 md:hidden">
        {variantFields.map((fieldName, index) => {
          if (!fieldName) return null;
          const currentValue = selectedValues[`field${index + 1}`];
          return (
            <div key={index} className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-700">
                {fieldName}:
              </span>
              <span className="font-medium">{currentValue}</span>
            </div>
          );
        })}
        <button
          onClick={() => setShowVariantModal(true)}
          className="w-full py-2 border border-gray-300 rounded-lg text-sm font-medium mt-2"
        >
          Change Variant
        </button>
      </div>
    );
  };

  // Render variant modal - for mobile
  const renderVariantModal = () => {
    if (!showVariantModal) return null;

    return (
      <div className="fixed inset-0 z-100 bg-black/30 bg-opacity-50 flex items-end md:hidden">
        <div className="w-full bg-white rounded-t-2xl p-4 max-h-[70vh] overflow-y-auto">
          {/* Modal Header */}
          <div className="border-b pb-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-lg">
                {productData.name || "Product Name"}
              </h3>
              <button onClick={handleCancel} className="text-gray-500 text-2xl">
                &times;
              </button>
            </div>
            <div className="mt-2">
              <span className="font-bold text-lg">
                ₹{currentVariant.price?.toLocaleString("en-IN") || "99,999"}
              </span>
              {currentVariant.mrp && (
                <span className="line-through text-gray-500 ml-2">
                  ₹{currentVariant.mrp?.toLocaleString("en-IN")}
                </span>
              )}
            </div>
          </div>

          {/* Variant Selectors */}
          {variantFields.map((fieldName, fieldIndex) => {
            if (!fieldName) return null;

            const filterValues = {};
            if (fieldIndex > 0) filterValues.fieldValue1 = tempSelection.field1;
            if (fieldIndex > 1) {
              filterValues.fieldValue1 = tempSelection.field1;
              filterValues.fieldValue2 = tempSelection.field2;
            }

            const options = getUniqueValues(fieldIndex, filterValues);
            const currentValue = tempSelection[`field${fieldIndex + 1}`];
            const isColorField = fieldName.toLowerCase().includes("color");

            return (
              <div key={fieldIndex} className="mt-6">
                <h4 className="font-medium text-gray-700 mb-3">
                  {fieldName}: {currentValue}
                </h4>
                <div
                  className={
                    isColorField
                      ? "grid grid-cols-4 gap-3"
                      : "grid grid-cols-2 gap-3"
                  }
                >
                  {options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() =>
                        setTempSelection((prev) => ({
                          ...prev,
                          [`field${fieldIndex + 1}`]: option,
                        }))
                      }
                      className={`
                        ${isColorField ? "p-2" : "p-3"}
                        border-2 rounded-lg ${
                          currentValue === option
                            ? isColorField
                              ? "border-rose-500 bg-rose-50"
                              : "border-black bg-black text-white"
                            : "border-gray-200"
                        }
                      `}
                    >
                      {isColorField ? (
                        <>
                          <div className="w-full aspect-square bg-gray-100 rounded flex items-center justify-center overflow-hidden">
                            <img
                              src={getValidImageSrc(
                                variants.find((v) =>
                                  fieldIndex === 0
                                    ? v.fieldValue1 === option
                                    : fieldIndex === 1
                                    ? v.fieldValue2 === option
                                    : v.fieldValue3 === option
                                )?.thumbnail
                              )}
                              alt={option}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          </div>
                          <span className="text-xs mt-1 block truncate">
                            {option}
                          </span>
                        </>
                      ) : (
                        option
                      )}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Action Buttons */}
          <div className="flex gap-3 mt-8 sticky bottom-0 bg-white pt-4 pb-2">
            <button
              onClick={handleCancel}
              className="flex-1 py-3 border border-gray-300 rounded-lg font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handleApply}
              className="flex-1 py-3 bg-black text-white rounded-lg font-medium"
            >
              Apply
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-3xl mx-auto font-sans bg-white rounded-lg shadow text-gray-800 px-4 py-6">
      {/* Header */}
      <div className="mb-6">
        <span className="text-sm font-semibold text-gray-600 uppercase tracking-wider">
          {productData.brand || "N AND J"}
        </span>
        <h1 className="text-2xl md:text-3xl font-bold mt-1 mb-2 text-gray-900">
          {productData.name || "Product Layout Style1"}
        </h1>

        <div className="flex items-center flex-wrap gap-2 mt-3">
          <div className="flex items-center">
            {renderStars(rating?.toFixed(1) || 0)}
            <span className="ml-1 text-sm text-gray-600">
              {"0.0" || rating}
            </span>
          </div>
          <span className="text-sm text-gray-500 hidden md:inline">|</span>
          <span className="text-sm text-gray-600 hidden md:inline">
            {"0 Reviews " || totalRatings}
          </span>
          <span className="text-sm text-gray-500 hidden md:inline">|</span>
          <a
            href="#rating"
            className="text-sm text-blue-600 hover:text-blue-800 hover:underline hidden md:inline"
          >
            Write a Review
          </a>
          <button
            onClick={() => setShowVariantModal(true)}
            className="text-blue-600 text-sm font-medium flex items-center md:hidden ml-auto"
          >
            View All <span className="ml-1 text-lg">›</span>
          </button>
        </div>
      </div>

      {/* Price Section */}
      <div className="mb-6 bg-gray-50 rounded-lg">
        <div className="flex items-center flex-wrap gap-3 mb-3">
          <span className="text-2xl font-bold text-red-600">
            ₹{currentVariant.price?.toLocaleString("en-IN") || "99.00"}
          </span>
          <span className="line-through text-gray-500">
            ₹{currentVariant.mrp?.toLocaleString("en-IN") || "135.00"}
          </span>
          {discountPercentage > 0 && (
            <span className="px-2 py-1 bg-green-100 text-green-800 text-sm font-semibold rounded">
              {discountPercentage}% OFF
            </span>
          )}
          <span
            className={`ml-auto text-sm font-medium px-2 py-1 rounded ${
              currentVariant.availablestock > 0
                ? "bg-green-100 text-green-800"
                : "bg-red-100 text-red-800"
            }`}
          >
            {currentVariant.availablestock > 0 ? "In Stock" : "Out of Stock"}
          </span>
        </div>

        {discountPercentage > 0 && (
          <div className="text-sm text-gray-600">
            You save: ₹{(currentVariant.mrp - currentVariant.price).toFixed(2)}
          </div>
        )}
      </div>

      {/* Render variant selectors dynamically - desktop */}
      <div className="flex gap-2 mb-6">
        {variantFields.map((_, index) => (
          <div key={index} className="w-1/3">
            {renderVariantSelector(index)}
          </div>
        ))}
      </div>

      {/* Render variant summary - mobile */}
      {renderVariantSummary()}

      {/* Coupon Section */}
      <div className="mb-6 bg-gradient-to-r from-green-50 to-cyan-50 p-4 rounded-lg border border-green-100">
        <div className="flex items-start gap-3">
          <RiCoupon2Fill className="text-green-600 text-xl mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-green-800 mb-1">Special Offer</h3>
            <p className="text-sm text-gray-700">
              Get extra 20% off up to ₹56 on 20 items. Price inclusive of
              cashback/coupon.
            </p>
            <button
              className="mt-2 text-sm text-green-700 font-medium hover:underline"
              onClick={() => router.push("/termsAndCondition")}
            >
              View Terms & Conditions
            </button>
          </div>
        </div>
      </div>
      {/* Additional Info */}
      <div className="space-y-3">
        <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg border border-red-100">
          <span className="bg-red-500 text-white text-xs font-semibold px-2 py-1 rounded-full">
            9
          </span>
          <span className="text-sm">
            People are viewing this product right now
          </span>
        </div>

        <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-100">
          <span className="text-blue-600">🚚</span>
          <span className="text-sm">
            Free shipping on orders over{" "}
            <span className="font-medium">₹199</span>
          </span>
        </div>
      </div>

      {/* Variant Modal - mobile */}
      {renderVariantModal()}
    </div>
  );
};

export default ProductDetails;
