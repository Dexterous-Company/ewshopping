"use client";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { FaStar, FaStarHalfAlt, FaRegStar } from "react-icons/fa";
import { FaRegCircleCheck } from "react-icons/fa6";
import { FaAngleDown, FaAngleUp } from "react-icons/fa";
import { useSelector, useDispatch } from "react-redux";
import { fetchReviews, addReview } from "@/redux/reviews/reviewSlice";
import { IoIosArrowForward } from "react-icons/io";
import EmptyReviews from "@/components/EmptyPages/EmptyReviews";

const ProductDetailSection = ({ title, data, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="w-full mb-4 border-b border-gray-200 pb-4">
      <div
        className="flex flex-row justify-between items-center font-medium cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-semibold text-gray-800">{title}</span>
        {isOpen ? (
          <FaAngleUp className="text-gray-500" />
        ) : (
          <FaAngleDown className="text-gray-500" />
        )}
      </div>

      {isOpen && (
        <div className="mt-3">
          <table className="w-full">
            <tbody>
              {data.map((item, index) => (
                <tr key={index} className="border-b border-gray-100">
                  <th className="py-3 pr-4 font-medium text-gray-600 text-left w-1/3">
                    {item.label}
                  </th>
                  <td className="py-3 text-gray-800">{item.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

const tabs = [
  { id: "description", label: "Description" },
  { id: "additionalInformation", label: "Specifications" },
  { id: "size-chart", label: "Size Guide" },
  { id: "shipping-return", label: "Shipping & Returns" },
  { id: "reviews", label: "Ratings & Reviews" },
];

const sizeChartData = [
  {
    category: "Ready to Wear Clothing",
    description:
      "This is a standardised guide to give you an idea of what size you will need, however some brands may vary from these conversions.",
    tableHeaders: [
      "Size",
      "XXS - XS",
      "XS - S",
      "S - M",
      "M - L",
      "L - XL",
      "XL - XXL",
    ],
    tableRows: [
      { label: "UK", values: ["6", "8", "10", "12", "14", "16"] },
      { label: "US", values: ["2", "4", "6", "8", "10", "12"] },
      { label: "Italy (IT)", values: ["38", "40", "42", "44", "46", "48"] },
      { label: "France (FR/EU)", values: ["34", "36", "38", "40", "42", "44"] },
      { label: "Denmark", values: ["32", "34", "36", "38", "40", "42"] },
      { label: "Russia", values: ["40", "42", "44", "46", "48", "50"] },
      { label: "Germany", values: ["32", "34", "36", "38", "40", "42"] },
      { label: "Japan", values: ["5", "7", "9", "11", "13", "15"] },
      { label: "Australia", values: ["6", "8", "10", "12", "14", "16"] },
      { label: "Korea", values: ["33", "44", "55", "66", "77", "88"] },
      {
        label: "China",
        values: ["160/84", "165/86", "170/88", "175/90", "180/92", "185/94"],
      },
      {
        label: "Jeans",
        values: ["24-25", "26-27", "27-28", "29-30", "31-32", "32-33"],
      },
    ],
  },
];

const shippingReturnData = [
  {
    title: "Shipping & Return Policy",
    items: [
      "Dispatch: Within 24 Hours",
      "1 Year Brand Warranty",
      "Free shipping on orders above $50",
      "International delivery: 7–10 business days",
      "Cash on delivery available",
      "Easy 30 days returns and exchanges",
    ],
  },
  {
    title: "Free and Easy Returns",
    description:
      "If you're not completely satisfied with your purchase, you can return it within 30 days for a full refund or exchange. Items must be unused, unworn, and in original condition with tags attached.",
  },
  {
    title: "Special Offers",
    description:
      "We frequently run special promotions and discounts. Subscribe to our newsletter to stay updated on the latest deals and offers.",
  },
];

const StarRating = ({
  rating,
  setRating,
  interactive = false,
  size = "md",
}) => {
  const starSize = size === "lg" ? "text-xl" : "text-base";

  return (
    <div className="inline-flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => {
        if (star <= Math.floor(rating)) {
          return (
            <span
              key={star}
              className={`${
                interactive ? "cursor-pointer" : ""
              } ${starSize} text-yellow-400`}
              onClick={() => interactive && setRating(star)}
            >
              <FaStar />
            </span>
          );
        } else if (star === Math.ceil(rating) && rating % 1 >= 0.5) {
          return (
            <span
              key={star}
              className={`${
                interactive ? "cursor-pointer" : ""
              } ${starSize} text-yellow-400`}
              onClick={() => interactive && setRating(star)}
            >
              <FaStarHalfAlt />
            </span>
          );
        } else {
          return (
            <span
              key={star}
              className={`${
                interactive ? "cursor-pointer" : ""
              } ${starSize} text-gray-300`}
              onClick={() => interactive && setRating(star)}
            >
              <FaStar />
            </span>
          );
        }
      })}
    </div>
  );
};

export default function ProductTabs() {
  const [activeTab, setActiveTab] = useState("description");
  const [hasUserReviewed, setHasUserReviewed] = useState(false);

  // Get reviews from Redux store
  const {
    rating,
    totalRatings,
    ratingBreakdown,
    customerReviews,
    status,
    error,
  } = useSelector((state) => state.reviews);

  const { product } = useSelector((state) => state.info);
  const productData = product?.[0] || {};
  const generalFields = productData?.generalFields || [];
  const dispatch = useDispatch();
  const navigate = useRouter();
  const { loginData } = useSelector((state) => state.Athentication);

  useEffect(() => {
    if (productData?._id && loginData?._id && customerReviews.length > 0) {
      console.log(customerReviews, "customerReviews");

      const userReview = customerReviews.find(
        (review) => review.userId === loginData._id
      );
      setHasUserReviewed(!!userReview);
    }
  }, [customerReviews, loginData, productData]);

  // Review form state
  const [formData, setFormData] = useState({
    name: loginData?.name || "",
    email: loginData?.email || "",
    title: "",
    rating: 5,
    content: "",
    userId: loginData?._id || "",
  });

  const [charsRemaining, setCharsRemaining] = useState(1500);

  // Fetch reviews when product changes or reviews tab is selected
  useEffect(() => {
    if (productData?._id && activeTab === "reviews") {
      console.log(productData, "productData");

      dispatch(fetchReviews(productData?._id));
    }
  }, [dispatch, productData?._id, activeTab]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    if (name === "content") {
      setCharsRemaining(1500 - value.length);
    }
  };

  const handleRatingChange = (newRating) => {
    setFormData((prev) => ({
      ...prev,
      rating: newRating,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const LData = JSON.parse(localStorage.getItem("loginData"));
    if (!LData) {
      navigate.push("/login");
    } else {
      dispatch(
        addReview({
          productId: productData._id,
          reviewData: formData,
        })
      )
        .unwrap()
        .then(() => {
          setFormData({
            name: loginData?.name || "",
            email: loginData?.email || "",
            title: "",
            rating: 5,
            content: "",
          });
          setCharsRemaining(1500);
        })
        .catch((err) => {
          console.error("Failed to submit review:", err);
        });
    }
  };

  // Generate dynamic sections from product data
  const dynamicSections = generalFields.map((field) => ({
    title: field.tag,
    data: field.fields.map((item) => ({
      label: item.name,
      value: item.value,
    })),
  }));

  const renderDescriptionTab = () => (
    <div className="product-description">
      <div className="space-y-6">
        <h3 className="text-xl font-semibold text-gray-800">
          Product Description
        </h3>
        <p className="text-gray-700">
          {productData.shortDescription ||
            "This premium quality product is designed to offer both style and comfort. Crafted with attention to detail, it's perfect for various occasions."}
        </p>

        {productData.productDetails && (
          <>
            <h4 className="text-lg font-semibold text-gray-800">
              Key Features
            </h4>
            <ul className="space-y-3">
              {productData.productDetails.split("\n").map((detail, index) => (
                <li
                  key={index}
                  className="flex items-start gap-3 text-gray-700"
                >
                  <FaRegCircleCheck className="text-blue-500 mt-1 flex-shrink-0" />
                  <span>{detail}</span>
                </li>
              ))}
            </ul>
          </>
        )}

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-800 mb-2">
            Why Choose This Product?
          </h4>
          <p className="text-blue-700">
            Our products are carefully selected to ensure the highest quality
            standards. Each item goes through rigorous quality checks before
            reaching you.
          </p>
        </div>
      </div>
    </div>
  );

  const renderAdditionalInfoTab = () => (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-800">
        Product Specifications
      </h3>
      {dynamicSections.map((section, idx) => (
        <ProductDetailSection
          key={idx}
          title={section.title}
          data={section.data}
          defaultOpen={idx === 0}
        />
      ))}

      {productData.CountryofOrigin && (
        <ProductDetailSection
          title="General Information"
          data={[
            { label: "Country of Origin", value: productData.CountryofOrigin },
            ...(productData.brand
              ? [{ label: "Brand", value: productData.brand }]
              : []),
          ]}
        />
      )}
    </div>
  );

  const renderSizeChartTab = () => (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-800">Size Guide</h3>
      {sizeChartData.map((chart, index) => (
        <div key={index} className="w-full">
          <h4 className="text-lg font-semibold mb-3 text-gray-800">
            {chart.category}
          </h4>
          <p className="text-gray-600 mb-4">{chart.description}</p>
          <div className="overflow-x-auto">
            <table className="min-w-full border border-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  {chart.tableHeaders.map((header, i) => (
                    <th
                      key={i}
                      className="px-4 py-3 text-left font-medium text-gray-700 border-b border-gray-200"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {chart.tableRows.map((row, rowIndex) => (
                  <tr key={rowIndex} className="hover:bg-gray-50">
                    <th className="px-4 py-3 text-left font-medium text-gray-700 border-b border-gray-200 bg-gray-50">
                      {row.label}
                    </th>
                    {row.values.map((value, valueIndex) => (
                      <td
                        key={valueIndex}
                        className="px-4 py-3 border-b border-gray-200"
                      >
                        {value}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );

  const renderShippingReturnTab = () => (
    <div className="space-y-8">
      <h3 className="text-xl font-semibold text-gray-800">
        Shipping & Returns
      </h3>

      {shippingReturnData.map((section, index) => (
        <div key={index} className="space-y-4">
          <h4 className="text-lg font-semibold text-gray-800">
            {section.title}
          </h4>

          {section.items ? (
            <ul className="space-y-3">
              {section.items.map((item, i) => (
                <li key={i} className="flex items-start gap-3 text-gray-700">
                  <IoIosArrowForward className="text-blue-500 mt-1 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-700">{section.description}</p>
          )}
        </div>
      ))}

      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
        <h4 className="font-semibold text-yellow-800 mb-2">Note:</h4>
        <p className="text-yellow-700">
          Please review our return policy carefully before making a purchase.
          Some items may have specific return conditions.
        </p>
      </div>
    </div>
  );

  const renderReviewsTab = () => {
    if (status === "loading" && customerReviews.length === 0) {
      return (
        <div className="text-center py-8">
          <div className="animate-pulse flex flex-col items-center">
            <div className="h-12 w-12 bg-gray-200 rounded-full mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      );
    }

    if (status === "failed") {
      return (
        <div className="bg-red-50 p-4 rounded-lg text-red-600 my-6">
          Error loading reviews: {error?.message || "Please try again later"}
        </div>
      );
    }

    return (
      <div className="space-y-8">
        <h3 className="text-xl font-semibold text-gray-800">
          Ratings & Reviews
        </h3>
        <div className="grid md:grid-cols-3 gap-8">
          {/* Left: Rating Summary */}
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-blue-50 rounded-full p-4">
                <span className="text-3xl font-bold text-blue-600">
                  {rating?.toFixed(1) || "0.0"}
                </span>
              </div>
              <div>
                <div className="mb-1">
                  <StarRating rating={rating || 0} size="lg" />
                </div>
                <p className="text-gray-600">
                  {totalRatings || 0} Ratings & Reviews
                </p>
              </div>
            </div>

            {/* Rating Breakdown */}
            <div className="space-y-3 mt-6">
              {[5, 4, 3, 2, 1].map((stars) => {
                const breakdown = ratingBreakdown?.find(
                  (r) => r.stars === stars
                ) || { percentage: 0, count: 0 };
                return (
                  <div key={stars} className="flex items-center space-x-3">
                    <span className="text-gray-600 w-8">{stars} Star</span>
                    <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-yellow-400 h-full"
                        style={{ width: `${breakdown.percentage || 0}%` }}
                      />
                    </div>
                    <span className="text-gray-500 text-sm w-10 text-right">
                      {breakdown.count || 0}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Reviews */}
          <div className="md:col-span-2 space-y-6">
            {customerReviews?.length > 0 ? (
              customerReviews.map((review, i) => (
                <div
                  key={i}
                  className="border-b border-gray-200 pb-6 last:border-0 last:pb-0"
                >
                  <div className="flex items-start space-x-4">
                    <div className="bg-gray-200 rounded-full w-12 h-12 flex items-center justify-center text-gray-600 font-semibold">
                      {review.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h5 className="font-semibold text-gray-800">
                          {review.name}
                        </h5>
                        <span className="text-sm text-gray-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="mb-2">
                        <StarRating rating={review.rating} />
                      </div>
                      <h6 className="font-medium text-gray-700 mb-1">
                        {review.title}
                      </h6>
                      <p className="text-gray-600">{review.content}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="bg-gray-50 p-6 rounded-lg text-center">
                <p className="text-gray-500 mb-4">
                  No reviews yet. Be the first to review this product!
                </p>
              </div>

              // <EmptyReviews />
            )}
          </div>
        </div>

        {/* Review Form */}
        {hasUserReviewed ? (
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center">
              <FaRegCircleCheck className="text-blue-500 mr-2" />
              <p className="text-blue-700">
                You have already reviewed this product.
                {customerReviews.find((r) => r.userId === loginData._id)
                  ?.content && (
                  <span>
                    {" "}
                    Your review: "
                    {
                      customerReviews.find((r) => r.userId === loginData._id)
                        .content
                    }
                    "
                  </span>
                )}
              </p>
            </div>
          </div>
        ) : (
          <>
            <div
              className="mt-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100"
            >
              <h4 className="text-lg font-semibold mb-4 text-gray-800">
                Write a Review
              </h4>
              <p className="text-sm text-gray-600 mb-6">
                Your email address will not be published. Required fields are
                marked <span className="text-red-500">*</span>
              </p>
              <form className="space-y-5" onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Name <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Review Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Summarize your review in a few words"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Rating <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center space-x-2">
                    <StarRating
                      rating={formData.rating}
                      setRating={handleRatingChange}
                      interactive={true}
                      size="lg"
                    />
                    <span className="text-sm text-gray-600">
                      {formData.rating} out of 5
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Review <span className="text-red-500">*</span>
                    <span className="text-gray-400 ml-2">
                      ({charsRemaining} characters remaining)
                    </span>
                  </label>
                  <textarea
                    rows={5}
                    name="content"
                    value={formData.content}
                    onChange={handleChange}
                    maxLength={1500}
                    className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Share your experience with this product..."
                    required
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
                    disabled={status === "loading"}
                  >
                    {status === "loading" ? (
                      <span className="flex items-center">
                        <svg
                          className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                        Submitting...
                      </span>
                    ) : (
                      "Submit Review"
                    )}
                  </button>
                </div>
              </form>
            </div>
          </>
          // Your existing review form here
        )}
      </div>
    );
  };

  return (
    <div className="w-full bg-white" id="rating">
      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <div className="container mx-auto px-4">
          <nav className="flex overflow-x-auto no-scrollbar -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-600 text-blue-600 font-semibold"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      <div className="container mx-auto px-4 py-8">
        {activeTab === "description" && renderDescriptionTab()}
        {activeTab === "additionalInformation" && renderAdditionalInfoTab()}
        {activeTab === "size-chart" && renderSizeChartTab()}
        {activeTab === "shipping-return" && renderShippingReturnTab()}
        {activeTab === "reviews" && renderReviewsTab()}
      </div>
    </div>
  );
}
