// "use client";
// import React, { useState } from "react";
// import RightSideCheckOut from "./RightSideCheckOut";
// import CheckoutLogin from "./CheckoutLogin";
// import OrderSummary from "./OrderSummary";
// import PaymentOptions from "./PaymentOptionsCheckOut";
// import { useSelector } from "react-redux";
// import CheckOutAddress from "./CheckoutAddress";
// import { motion, AnimatePresence } from "framer-motion";

// const CheckoutPage = () => {
//   const { loginData, otp, mob, isAuth } = useSelector(
//     (store) => store.Athentication
//   );
//   const [showSummary, setShowSummary] = useState(false);
//   const [continueSummary, setContinueSummary] = useState(false);
//   const [continueSumamryData, setContinueSumamryData] = useState(false);

//   // Define the 4-step progression
//   const steps = [
//     {
//       step: 1,
//       label: "Login",
//       active: true,
//       completed: isAuth,
//     },
//     {
//       step: 2,
//       label: "Address",
//       active: isAuth,
//       completed: showSummary,
//     },
//     {
//       step: 3,
//       label: "Summary",
//       active: showSummary,
//       completed: continueSumamryData,
//     },
//     {
//       step: 4,
//       label: "Payment",
//       active: continueSumamryData,
//       completed: false,
//     },
//   ];

//   return (
//     <div className="min-h-screen bg-gray-50 py-8">
//       <div className="sm:px-6 lg:px-8">
//         <div className="flex flex-col lg:flex-row gap-8">
//           {/* Left section - Main content */}
//           <div className="w-full lg:w-2/3 flex flex-col gap-6">
//             {/* Login Section */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               transition={{ duration: 0.4 }}
//             >
//               <CheckoutLogin />
//             </motion.div>

//             {/* Address Section */}
//             <AnimatePresence>
//               {isAuth && (
//                 <motion.div
//                   initial={{ opacity: 0, y: 20 }}
//                   animate={{ opacity: 1, y: 0 }}
//                   exit={{ opacity: 0, y: -20 }}
//                   transition={{ duration: 0.4 }}
//                 >
//                   <CheckOutAddress setShowSummary={setShowSummary} />
//                 </motion.div>
//               )}
//             </AnimatePresence>

//             {/* Order Summary */}
//             <AnimatePresence>
//               {isAuth && showSummary && (
//                 <motion.div
//                   initial={{ opacity: 0, y: 20 }}
//                   animate={{ opacity: 1, y: 0 }}
//                   exit={{ opacity: 0, y: -20 }}
//                   transition={{ duration: 0.4 }}
//                 >
//                   <OrderSummary
//                     showSummary={showSummary}
//                     setContinueSumamryData={setContinueSumamryData}
//                     continueSumamryData={continueSumamryData}
//                   />
//                 </motion.div>
//               )}
//             </AnimatePresence>

//             {/* Payment Options */}
//             <AnimatePresence>
//               {isAuth && continueSumamryData && showSummary && (
//                 <motion.div
//                   initial={{ opacity: 0, y: 20 }}
//                   animate={{ opacity: 1, y: 0 }}
//                   exit={{ opacity: 0, y: -20 }}
//                   transition={{ duration: 0.4 }}
//                 >
//                   <PaymentOptions
//                     continueSumamryData={continueSumamryData}
//                     showSummary={showSummary}
//                   />
//                 </motion.div>
//               )}
//             </AnimatePresence>
//           </div>

//           {/* Right section - Sticky sidebar */}
//           <div className="w-full lg:w-1/3 lg:min-w-[350px]">
//             <div className="lg:sticky lg:top-8 space-y-6">
//               {/* Order Summary Card */}
//               <motion.div
//                 initial={{ opacity: 0, x: 20 }}
//                 animate={{ opacity: 1, x: 0 }}
//                 transition={{ duration: 0.4, delay: 0.2 }}
//                 className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
//               >
//                 <div className="bg-white border-b border-gray-200 px-6 py-4">
//                   <h3 className="text-lg font-semibold text-gray-900">
//                     Order Summary
//                   </h3>
//                 </div>
//                 <RightSideCheckOut />
//               </motion.div>

//               {/* Security Badge */}
//               <motion.div
//                 initial={{ opacity: 0, scale: 0.9 }}
//                 animate={{ opacity: 1, scale: 1 }}
//                 transition={{ duration: 0.4, delay: 0.3 }}
//                 className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-20 sm:mb-0"
//               >
//                 <div className="flex items-center gap-4">
//                   <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
//                     <span className="text-lg">🔒</span>
//                   </div>
//                   <div>
//                     <p className="font-medium text-gray-900 text-sm">
//                       Secure Checkout
//                     </p>
//                     <p className="text-gray-600 text-xs mt-1">
//                       Your payment information is encrypted and secure
//                     </p>
//                   </div>
//                 </div>
//               </motion.div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default CheckoutPage;

"use client";
import React, { useState } from "react";
import RightSideCheckOut from "./RightSideCheckOut";
import CheckoutLogin from "./CheckoutLogin";
import OrderSummary from "./OrderSummary";
import PaymentOptions from "./PaymentOptionsCheckOut";
import { useSelector } from "react-redux";
import CheckOutAddress from "./CheckoutAddress";
import { motion, AnimatePresence } from "framer-motion";

const CheckoutPage = () => {
  const { loginData, otp, mob, isAuth } = useSelector(
    (store) => store.Athentication
  );
  const [showSummary, setShowSummary] = useState(false);
  const [continueSummary, setContinueSummary] = useState(false);
  const [continueSumamryData, setContinueSumamryData] = useState(false);

  // Define the 4-step progression
  const steps = [
    {
      step: 1,
      label: "Login",
      active: true,
      completed: isAuth,
    },
    {
      step: 2,
      label: "Address",
      active: isAuth,
      completed: showSummary,
    },
    {
      step: 3,
      label: "Summary",
      active: showSummary,
      completed: continueSumamryData,
    },
    {
      step: 4,
      label: "Payment",
      active: continueSumamryData,
      completed: false,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-4 sm:py-6 lg:py-8">
      <div className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Progress Steps - Mobile & Tablet */}
        {/* <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="lg:hidden mb-6"
        >
          <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-sm font-semibold text-gray-900">
                Checkout Progress
              </h3>
              <span className="text-xs text-gray-500">
                Step {steps.findIndex((step) => step.active) + 1} of 4
              </span>
            </div>
            <div className="flex items-center justify-between">
              {steps.map((step, index) => (
                <React.Fragment key={step.step}>
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${
                        step.completed
                          ? "bg-green-500 text-white"
                          : step.active
                          ? "bg-blue-500 text-white"
                          : "bg-gray-200 text-gray-500"
                      }`}
                    >
                      {step.completed ? "✓" : step.step}
                    </div>
                    <span
                      className={`text-xs mt-1 ${
                        step.active || step.completed
                          ? "text-gray-900 font-medium"
                          : "text-gray-500"
                      }`}
                    >
                      {step.label}
                    </span>
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-2 ${
                        step.completed ? "bg-green-500" : "bg-gray-200"
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </motion.div> */}

        <div className="flex flex-col lg:flex-row gap-4 sm:gap-6 lg:gap-8">
          {/* Left section - Main content */}
          <div className="w-full lg:w-2/3 flex flex-col gap-4 sm:gap-6">
            {/* Login Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
            >
              <CheckoutLogin />
            </motion.div>

            {/* Address Section */}
            <AnimatePresence>
              {isAuth && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
                >
                  <CheckOutAddress setShowSummary={setShowSummary} />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Order Summary */}
            <AnimatePresence>
              {isAuth && showSummary && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
                >
                  <OrderSummary
                    showSummary={showSummary}
                    setContinueSumamryData={setContinueSumamryData}
                    continueSumamryData={continueSumamryData}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Payment Options */}
            <AnimatePresence>
              {isAuth && continueSumamryData && showSummary && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                  className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
                >
                  <PaymentOptions
                    continueSumamryData={continueSumamryData}
                    showSummary={showSummary}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Right section - Sticky sidebar */}
          <div className="w-full lg:w-1/3 lg:min-w-[350px]">
            <div className="space-y-4 sm:space-y-6">
              {/* Order Summary Card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.2 }}
                className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
              >
                <div className="bg-white border-b border-gray-200 px-4 sm:px-6 py-3 sm:py-4">
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                    Order Summary
                  </h3>
                </div>
                <RightSideCheckOut />
              </motion.div>

              {/* Security Badge */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.3 }}
                className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 sm:p-6"
              >
                <div className="flex items-center gap-3 sm:gap-4">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-base sm:text-lg">🔒</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 text-sm sm:text-base">
                      Secure Checkout
                    </p>
                    <p className="text-gray-600 text-xs sm:text-sm mt-1">
                      Your payment information is encrypted and secure
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
