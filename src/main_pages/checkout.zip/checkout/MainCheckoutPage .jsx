import React from 'react'
import CheckoutPage from './CheckoutPage'


const MainCheckoutPage = () => {
  return (
    <div>
      <CheckoutPage />
    </div>
  )
}

export default MainCheckoutPage 
